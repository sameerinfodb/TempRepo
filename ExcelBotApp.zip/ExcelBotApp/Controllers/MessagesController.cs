﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using Microsoft.Bot.Connector;
using Newtonsoft.Json;
using Microsoft.Bot.Builder.Dialogs;
using ExcelBotApp.Dialogs;

namespace ExcelBotApp
{
    [BotAuthentication]
    public class MessagesController : ApiController
    {
        /// <summary>
        /// POST: api/Messages
        /// Receive a message from a user and reply to it
        /// </summary>
        [BotAuthentication]
        public virtual async Task<HttpResponseMessage> Post([FromBody]Activity activity)
        {
            #region Set CurrentBaseURL
            // Get the base URL that this service is running at
            // This is used to show images
            string currentBaseUrl =
                    this.Url.Request.RequestUri.AbsoluteUri.Replace(@"api/messages", "");
            // Create an instance of BotData to store data
            BotData objBotData = new BotData();
            // Instantiate a StateClient to save BotData            
            StateClient stateClient = activity.GetStateClient();
            // Use stateClient to get current userData
            BotData userData = await stateClient.BotState.GetUserDataAsync(
                activity.ChannelId, activity.From.Id);
            // Update userData by setting CurrentBaseURL and Recipient
            userData.SetProperty<string>("CurrentBaseURL", currentBaseUrl);
            // Save changes to userData
            await stateClient.BotState.SetUserDataAsync(
                activity.ChannelId, activity.From.Id, userData);
            #endregion



            if (activity != null && activity.GetActivityType() == ActivityTypes.Message)
            {
                      
                    await Conversation.SendAsync(activity, () => new LUISBasedDialog());
               
            }
            else
            {
                this.HandleSystemMessage(activity);
            }
            return new HttpResponseMessage(System.Net.HttpStatusCode.Accepted);
        }

        private Activity HandleSystemMessage(Activity message)
        {
            if (message.Type == ActivityTypes.Ping)
            {
                Activity reply = message.CreateReply();
                reply.Type = ActivityTypes.Ping;
                return reply;
            }

            return null;
        }
    }
}
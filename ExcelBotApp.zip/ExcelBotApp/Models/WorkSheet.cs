﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExcelBotApp.Models
{
    [Serializable]
    public class WorkSheet
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string WorkBookID { get; set; }

        public override string ToString()
        {

            return this.Name.Length > 255 ? this.Name.Substring(0, 255) : this.Name;
        }
    }
}
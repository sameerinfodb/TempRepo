﻿using System;

namespace ExcelBotApp.Models
{
    [Serializable]
    public class Chart
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string WorkSheetName { get; set; }

        public override string ToString()
        {

            return this.Name.Length > 255 ? this.Name.Substring(0, 255) : this.Name;
        }
    }
}
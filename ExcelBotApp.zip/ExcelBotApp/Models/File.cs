﻿

namespace ExcelBotApp.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    [Serializable]
    public class File
    {
        public string CreatedBy { get; set; }
        public DateTimeOffset CreatedDate { get; set; }
        public string ID { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTimeOffset LastModifiedDate { get; set; }
        public string Name { get; set; }
        public string WebURL { get; set; }

        public override string ToString()
        {

            return this.Name.Length > 255 ? this.Name.Substring(0, 255) : this.Name;
        }
    }
}
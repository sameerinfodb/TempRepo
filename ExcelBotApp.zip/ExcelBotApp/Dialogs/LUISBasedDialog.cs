﻿using AuthBot;
using AuthBot.Dialogs;
using AuthBot.Models;
using ExcelBotApp.Models;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Hosting;

namespace ExcelBotApp.Dialogs
{
    #region Confidential
    [LuisModel("07c9a845-b1f6-4509-a66a-3ee757754743", "41bfe94139aa49c8a6e844d685a333e8")]
    #endregion 
   
    [Serializable]
    public class LUISBasedDialog :LuisDialog<object>
    {
        private string strBaseURL;
        [LuisIntent("Introduction")]
        public async Task AboutMe(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var message =await activity;
            await context.PostAsync("Hi! I'm a Excel bot, I can connect to excel online and get you the chart from the excel sheet.You can type 'Generate Issue summary chart' to fetch Chart from excel worksheet. For more details refer https://aigexcelbot.azurewebsites.net//");
            context.Wait(this.MessageReceived);
        }

        [LuisIntent("")]
        public async Task None(IDialogContext context, LuisResult result)
        {
            await context.PostAsync("Sorry, I don't understand what you are talking about !!!");
            context.Wait(this.MessageReceived);
        }

        [LuisIntent("GenerateIssueSummaryChart")]
        public async Task IssueReport(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
        
            //Assume this is a query for OneDrive so let's get an access token
            if (string.IsNullOrEmpty(await context.GetAccessToken(AuthSettings.Scopes)))
            {
                await context.PostAsync("To Generate Issue Summary chart,you would need to login to OneDrive by typing login, by doing this you would enable me to fetch data from your excel online.");
                context.Wait(MessageReceived);
            }
            else
            {
                var files = await SearchOneDrive("xlsx", await context.GetAccessToken(AuthSettings.Scopes));

                PromptDialog.Choice(context, DisplayExcelFileList, files, "From which file do you want fetch a chart?", null, 3, PromptStyle.PerLine);
            }
          
        }
        
        [LuisIntent("Login")]
        public async Task Authenticate(IDialogContext context,IAwaitable<IMessageActivity> activity,LuisResult luisResult)
        {
            var message = await activity;

            if(string.IsNullOrEmpty(await context.GetAccessToken(AuthSettings.Scopes)))
            {
                await context.Forward(new AzureAuthDialog(AuthSettings.Scopes), this.ResumeAfterAuth, message, CancellationToken.None);
            }
            else
            {
                await context.PostAsync("You are already logged in");
                context.Wait(MessageReceived);
            }
        }

        [LuisIntent("Logout")]
        public async Task Logout(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            await context.Logout();
            context.Wait(this.MessageReceived);
        }

        [LuisIntent("GenerateSummaryChart")]
        public async Task GeneratSummaryChart(IDialogContext context, IAwaitable<IMessageActivity> activity,LuisResult result)
        {
           
            var chartName =string.Empty;
            int imageHeight = 100;
            int imageWidth = 100;
            string workSheetName = null;
            List<WorkSheet> workSheets=new List<WorkSheet>();
            EntityRecommendation rec;
            if (result.TryFindEntity("WorksheetName",out rec))
            {
                IBotDataBag conversationData = context.ConversationData;
                if (conversationData.TryGetValue<List<WorkSheet>>("WorkSheets", out workSheets))
                {
                    workSheetName = rec.Entity;
                    WorkSheet workSheet = workSheets.First(s => s.Name.Equals(workSheetName, StringComparison.OrdinalIgnoreCase));
                    List<Chart> charts = await GetCharts(workSheet.WorkBookID, workSheet.Name, await context.GetAccessToken(AuthSettings.Scopes));
                    if (charts.Count() > 0)
                    {
                        await PostChartImage(context, workSheet.WorkBookID, workSheet.Name, charts.First<Chart>().Name, imageHeight, imageWidth);
                    }
                    else
                    {
                        await context.PostAsync("we dont have chart in this worksheet");
                    }
                }
                else
                {
                   await IssueReport(context, activity, result);
                }
            }
            else
            {
                await context.PostAsync("Sorry, we dont have this worksheet in this workbook");
            }
            
            context.Wait(this.MessageReceived);
        }

        #region Helper Methods
        private async Task<List<Models.File>> SearchOneDrive(string search, string token)
        {
            List<Models.File> files = new List<Models.File>();
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var result = await client.GetAsync("https://graph.microsoft.com/v1.0/me/drive/root/search(q='" + HttpUtility.UrlEncode(search) + "')");
                var resultString = await result.Content.ReadAsStringAsync();

                var jResult = JObject.Parse(resultString);
                JArray jFiles = (JArray)jResult["value"];
                foreach (JObject item in jFiles)
                {
                    Models.File f = new Models.File();
                    f.CreatedBy = item["createdBy"]["user"].Value<string>("displayName");
                    f.CreatedDate = DateTimeOffset.Parse(item.Value<string>("createdDateTime"));
                    f.ID = item.Value<string>("id");
                    f.LastModifiedBy = item["lastModifiedBy"]["user"].Value<string>("displayName");
                    f.LastModifiedDate = DateTimeOffset.Parse(item.Value<string>("lastModifiedDateTime"));
                    f.Name = item.Value<string>("name");
                    f.WebURL = item.Value<string>("webUrl");
                    files.Add(f);
                    if (files.Count > 10)
                        return files;

                }
                return files;
            }
        }

        private async Task ResumeAfterAuth(IDialogContext context, IAwaitable<string> result)
        {
            var message = await result;
            await context.PostAsync(message);
            await context.PostAsync("If you want me to log you off, just say \"logout\". Now how can i help you?");
            context.Wait(MessageReceived);
        }


        private async Task<List<Models.WorkSheet>> GetWorksheets(string fileid, string token)
        {
            List<Models.WorkSheet> workSheet = new List<Models.WorkSheet>();
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                //Set up workbook and worksheet endpoints
                var workbookEndpoint = "https://graph.microsoft.com/v1.0/me/drive/items/" + fileid + "/workbook";
                var worksheetsEndpoint = workbookEndpoint + "/worksheets";

                var result = await client.GetAsync(worksheetsEndpoint);
                if (result.IsSuccessStatusCode)
                {

                    var resultString = await result.Content.ReadAsStringAsync();
                    CultureInfo enUS = new CultureInfo("en-US");
                    var jResult = JObject.Parse(resultString);
                    JArray jFiles = (JArray)jResult["value"];
                    foreach (JObject item in jFiles)
                    {
                        Models.WorkSheet w = new Models.WorkSheet();
                        w.ID = item.Value<string>("id");
                        w.Name = item.Value<string>("name");
                        w.WorkBookID = fileid;
                        workSheet.Add(w);
                        if (workSheet.Count > 10)
                            return workSheet;

                    }
                }

                return workSheet;
            }
        }

        private async Task DisplayExcelFileList(IDialogContext context, IAwaitable<Models.File> file)
        {
            var fileID = (await file).ID;

            IBotDataBag conversationData = context.ConversationData;

            conversationData.SetValue("FileID", fileID);

            //Get all the worksheet name
            var worksheets = await GetWorksheets(fileID, await context.GetAccessToken(AuthSettings.Scopes));
            conversationData.SetValue<List<WorkSheet>>("WorkSheets", worksheets);

            PromptDialog.Choice(context, DisplayWorksheets, worksheets, "Select the Worksheet from which chart need to be displayed?", null, 3, PromptStyle.PerLine);
        }

        private async Task DisplayWorksheets(IDialogContext context, IAwaitable<WorkSheet> workSheet)
        {
            IBotDataBag conversationData = context.ConversationData;


            WorkSheet workSheetName = await workSheet;
            List<Chart> charts= await GetCharts(workSheetName.WorkBookID,workSheetName.Name,await context.GetAccessToken(AuthSettings.Scopes));
            if (charts.Count>0)
            {
                int imageHeight = 100;
                int imageWidth = 100;
                conversationData.SetValue<WorkSheet>("WorkSheet", workSheetName);
                context.UserData.TryGetValue<string>("CurrentBaseURL", out strBaseURL);
                await PostChartImage(context, workSheetName.WorkBookID, workSheetName.Name, charts.First<Chart>().Name, imageHeight, imageWidth);
               
            }
            else
            {
                await context.PostAsync("we dont have chart in this worksheet");
            }
            context.Wait(this.MessageReceived);
        }

        private async Task PostChartImage(IDialogContext context, string workBookID, string workSheetName, string chartName, int imageHeight, int imageWidth)
        {
            var base64ImageString = await GetChartImage(workBookID, workSheetName, chartName, imageHeight, imageWidth, await context.GetAccessToken(AuthSettings.Scopes));
            if (base64ImageString.Length > 0)
            {
                string URL = SaveBase64ImageString(base64ImageString, chartName);


                var activity = context.MakeMessage();
                activity.Attachments.Add(new Attachment()
                {
                    ContentUrl = URL,
                    ContentType = "image/png",
                    Name = chartName
                });
                //create the cardImage
                await context.PostAsync(activity);

            }
            else
            {
                await context.PostAsync("Sorry, we dont have this worksheet or chart in this workbook");
            }
        }

        private string SaveBase64ImageString(string base64ImageString, string chartName)
        {

            string imagePath = HostingEnvironment.ApplicationPhysicalPath + "\\Images\\" + chartName + ".png";

            Bitmap bitmap = StringToBitmap(base64ImageString);
            bitmap.Save(imagePath, ImageFormat.Png);
            return strBaseURL + "/Images/" + chartName + ".png";
        }
        public static Bitmap StringToBitmap(string base64ImageString)
        {
            Bitmap bmpReturn = null;
            byte[] byteBuffer = Convert.FromBase64String(base64ImageString);
            MemoryStream memoryStream = new MemoryStream(byteBuffer);

            memoryStream.Position = 0;

            bmpReturn = (Bitmap)Image.FromStream(memoryStream);
            memoryStream.Close();
            memoryStream = null;
            byteBuffer = null;
            return bmpReturn;


        }

        private async Task<string> GetChartImage(string workBookID, string workSheetName, string chartName, int imageHeight,
            int imageWidth, string token)
        {
            string output = String.Empty;

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                //workbook/worksheets(<id|name>)/charts(<name>)/Image(width=0,height=0,fittingMode='fit')
                var chartEndpoint = "https://graph.microsoft.com/v1.0/me/drive/items/" + workBookID + "/workbook/worksheets('" + workSheetName + "')/charts('" + chartName + "')";
                var imageEndpoint = chartEndpoint + "/Image(width=0,height=0,fittingMode='fit')";

                var result = await client.GetAsync(imageEndpoint);
                if (result.IsSuccessStatusCode)
                {
                    var resultString = await result.Content.ReadAsStringAsync();
                    var jResult = JObject.Parse(resultString);
                    JValue jValue = (JValue)jResult["value"];
                    output = jValue.Value.ToString();
                }

            }
            return output;
        } 


        private async Task<List<Models.Chart>> GetCharts(string workBookID,string workSheetName,string token)
        {

            List<Models.Chart> charts = new List<Models.Chart>();

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                //workbook/worksheets(<id|name>)/charts(<name>)/Image(width=0,height=0,fittingMode='fit')
                var chartEndpoint = "https://graph.microsoft.com/v1.0/me/drive/items/" + workBookID + "/workbook/worksheets('" + workSheetName + "')/charts";
                

                var result = await client.GetAsync(chartEndpoint);
                if (result.IsSuccessStatusCode)
                {
                    var resultString = await result.Content.ReadAsStringAsync();
                    var jResult = JObject.Parse(resultString);
                    JArray jCharts = (JArray)jResult["value"];

                    foreach (JObject item in jCharts)
                    {
                        Models.Chart w = new Models.Chart();
                        w.ID = item.Value<string>("id");
                        w.Name = item.Value<string>("name");
                        w.WorkSheetName = workSheetName;
                        charts.Add(w);
                        if (charts.Count > 10)
                            return charts;

                    }
                  
                }

            }
            return charts;
        }
        #endregion
    }
}
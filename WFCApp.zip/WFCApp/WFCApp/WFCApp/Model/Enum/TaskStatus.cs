﻿
namespace WFCApp.Model
{
    
    public enum TaskStatus
    {
        NONE=0,
        OPEN=1,
        CLOSED=2
    }
}
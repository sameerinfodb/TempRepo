﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace WFCApp.View
{
    public partial class TaskDetailEditPage : ContentPage
    {
        
        public TaskDetailEditPage(Model.Task task)
        {
            InitializeComponent();

            int index = 0;
            int currentSelectedTaskStatusIndex = 0;

            //Fill the Items from the enum
            foreach (var value in Enum.GetValues(typeof(Model.TaskStatus)))
            {
                thePicker.Items.Add(value.ToString());
                if(value.ToString() == task.Status.ToString())
                {
                    currentSelectedTaskStatusIndex = index;
                }
                index++;

            }
            thePicker.SelectedIndex = currentSelectedTaskStatusIndex;
            this.BindingContext = task;
        }

        void SaveTaskButton_OnClick(object sender,EventArgs e)
        {
            Button btn = (Button)sender;
            Model.Task task = btn.CommandParameter as Model.Task;
            task.Status =(Model.TaskStatus)Enum.Parse(typeof(Model.TaskStatus), thePicker.Items[this.thePicker.SelectedIndex].ToString());
            DisplayAlert("Task Status changed to.", ((Model.TaskStatus)task.Status).ToString(),"OK");
            
        }

       


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WFCApp.Model;
using Xamarin.Forms;

namespace WFCApp.View
{
    public partial class TaskDetailPage : ContentPage
    {
        private Model.Task _task;
        public TaskDetailPage(Model.Task task)
        {
            InitializeComponent();
                _task = task;
            this.BindingContext = _task;
        }

        void UpdateTaskButton_Click(object sender,EventArgs e)
        {
            Button btn = (Button)sender;
            Model.Task task = btn.CommandParameter as Model.Task;

            if (task != null)
            {
                this.Navigation.PushAsync(new TaskDetailEditPage(task));
            }
        }


    }
}

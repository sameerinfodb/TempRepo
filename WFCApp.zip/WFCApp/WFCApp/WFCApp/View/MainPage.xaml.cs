﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using WFCApp.Model;
using Xamarin.Forms;

namespace WFCApp.View
{
    public partial class MainPage : ContentPage
    {

        List<BusinessUnit> _buList = new List<BusinessUnit>();
        public MainPage()
        {
            InitializeComponent();

            
        }


        private void OnClick(object sender, EventArgs e)
        {
            MenuItem item = sender as MenuItem;

            if (item != null)
                _buList =GetBUList(Convert.ToInt32(item.CommandParameter.ToString()));


            //if (item != null)
            //    DisplayAlert("Item Select",$"{item.Text} is clicked which has command paramater value {item.CommandParameter}", "OK");

            this.Navigation.PushAsync(new BUPage(_buList));

        }

        private List<BusinessUnit> GetBUList(int itemCommandParameter)
        {
            var BUID = itemCommandParameter;
            var _tempList = new List<BusinessUnit>();

            //for (int i = 1; i < 100; i++)
            //{
            //    _tempList.Add(new BusinessUnit() {ID = i, Name = "Business Unit" + i + " -" + BUID});
            //}

            _tempList.Add(new BusinessUnit() { ID = 1, Name= "My CCAR Tasks" });
            _tempList.Add(new BusinessUnit() { ID = 2, Name = "AIG Capital Planning" });
            _tempList.Add(new BusinessUnit() { ID = 3, Name = "AIG Global Economics " });
            _tempList.Add(new BusinessUnit() { ID = 4, Name = "CCAR Reporting" });
            _tempList.Add(new BusinessUnit() { ID = 5, Name = "Commercial" });
            _tempList.Add(new BusinessUnit() { ID = 6, Name = "Consumer" });
            _tempList.Add(new BusinessUnit() { ID = 7, Name = "Corporate ERM" });
            _tempList.Add(new BusinessUnit() { ID = 8, Name = "Corporate FPA" });
            _tempList.Add(new BusinessUnit() { ID = 9, Name = "Direct Investment and Global Capital" });
            _tempList.Add(new BusinessUnit() { ID = 10, Name = "Global Actuarial" });
            _tempList.Add(new BusinessUnit() { ID = 11, Name = "Global Real Estate" });
            _tempList.Add(new BusinessUnit() { ID = 12, Name = "Governance" });
            _tempList.Add(new BusinessUnit() { ID = 13, Name = "Human Resources Benefits Accounting" });
            _tempList.Add(new BusinessUnit() { ID = 14, Name = "Investment Accounting" });
            _tempList.Add(new BusinessUnit() { ID = 15, Name = "Investments ERM" });
            _tempList.Add(new BusinessUnit() { ID = 16, Name = "Life Settlements" });
            _tempList.Add(new BusinessUnit() { ID = 17, Name = "Parent" });
            _tempList.Add(new BusinessUnit() { ID = 18, Name = "Risk Disclosure and External Reporting" });
            _tempList.Add(new BusinessUnit() { ID = 19, Name = "Tax" });
            _tempList.Add(new BusinessUnit() { ID = 20, Name = "Treasury" });
            _tempList.Add(new BusinessUnit() { ID = 21, Name = "United Guaranty Corporation" });
            return _tempList;
        }
    }
}

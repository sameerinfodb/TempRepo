﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WFCApp.Model;
using Xamarin.Forms;

namespace WFCApp.View
{
    public partial class HomePage : MasterDetailPage
    {
        public HomePage(IEnumerable<BusinessUnit> BUList)
        {
            InitializeComponent();

          

        }

   }
}

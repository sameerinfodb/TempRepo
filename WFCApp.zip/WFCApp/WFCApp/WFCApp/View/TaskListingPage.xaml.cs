﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace WFCApp.View
{
    public partial class TaskListingPage : ContentPage
    {
      
        public TaskListingPage(IEnumerable<Model.Task> taskList)
        {
            
            InitializeComponent();
            _tasks = taskList.ToList();
            TasklistView.ItemsSource = this.Tasks;
        }

        private void TasklistView_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem == null)
            {
                return; //ItemSelected is called on deselection, which results in SelectedItem being set to null
            }

            var task = e.SelectedItem as Model.Task;

            if (task != null)
            {
               this.Navigation.PushAsync(new TaskDetailPage(task));
            }
        }

        protected void UpdateTaskButton_OnClick(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            Model.Task task = btn.CommandParameter as Model.Task;
            
            if (task != null)
            {
                this.Navigation.PushAsync(new TaskDetailEditPage(task));
            }
        }

        private void TasklistView_OnRefreshing(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Model.Task> Tasks { get { return _tasks;} }
        private List<Model.Task> _tasks=null;
        
    }
}

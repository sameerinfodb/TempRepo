﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WFCApp.Model;
using Xamarin.Forms;
using Task = System.Threading.Tasks.Task;

namespace WFCApp.View
{
    public partial class BUPage : ContentPage
    {
        public ListView ListView { get { return BUlistView; } }
        public BUPage(IEnumerable<BusinessUnit> buList)
        {
            InitializeComponent();
            BUlistView.ItemsSource = buList;
        }

        private void BUlistView_OnRefreshing(object sender, EventArgs e)
        {
            var list = (ListView)sender;
            //make sure to end the refresh state
            list.IsRefreshing = false;
        }

        private void BUlistView_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem == null)
            {
                return; //ItemSelected is called on deselection, which results in SelectedItem being set to null
            }
            var businessUnit = e.SelectedItem as BusinessUnit;

            if (businessUnit != null)
            {
                var taskList = GetTaskByBUName(businessUnit.Name);
                this.Navigation.PushAsync(new TaskListingPage(taskList));
            }

        }

        private IEnumerable<Model.Task> GetTaskByBUName(string businessUnitName)
        {
            var BUID = businessUnitName;
            var _taskList = new List<Model.Task>();

            for (int i = 1; i < 100; i++)
            {
                _taskList.Add(new Model.Task() { ID = i, Name = "Task" + i + " -" + BUID,Parent=null,Status=Model.TaskStatus.OPEN });
            }
            return _taskList;

        }

        private void BUlistView_OnItemTapped(object sender, ItemTappedEventArgs e)
        {
            DisplayAlert("Item Tapped", e.Item.ToString(), "Ok");
        }
    }
}
